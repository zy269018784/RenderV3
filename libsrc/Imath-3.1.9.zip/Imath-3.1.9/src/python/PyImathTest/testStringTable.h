void testStringTable();

